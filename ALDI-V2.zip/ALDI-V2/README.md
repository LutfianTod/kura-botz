<div align="center">
<img src="https://telegra.ph/file/80cf40cdc05bed2e2f41e.jpg" alt="GURA BASE" width="300" />

# GURA WANGY

>
>
>
</div>
<p align="center">
  <a href="https://github.com/DepinKunn"><img title="Author" src="https://img.shields.io/badge/Author-DepinKunn-red.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
  <a href="https://wa.me/628871746203"> THIS MY AUTHOR >//< </a>
</h4>
</p>

# MY GROUP CHAT↓
[Gura Bot User](https://chat.whatsapp.com/HtupgW2zN9C6aNzktp3bX9)

## CARA INSTALL DI TERMUX
```bash
> Ada Di Tutorial
```
## CARA INSTALL DI LAPTOP
```bash
> git clone https://github.com/DepinKunn/GuraBase
> cd GuraBase
> npm i
> node main.js
```

# INSTALL
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)
* [Libwebp](https://developers.google.com/speed/webp/download)

  # Thanks
* [`Baileys`](https://github.com/adiwajshing/Baileys)
* [`Depin`](https://github.com/DepinKunn)
  
  
